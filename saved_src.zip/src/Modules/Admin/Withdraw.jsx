import React from 'react'

const Withdraw = () => {
  return (
    <div>Withdraw</div>
  )
}

export default Withdraw