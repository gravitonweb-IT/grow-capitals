import React from 'react'

const StockForm = () => {
  return (
    <div>StockForm</div>
  )
}

export default StockForm