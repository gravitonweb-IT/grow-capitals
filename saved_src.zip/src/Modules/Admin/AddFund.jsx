import React from 'react'

const AddFund = () => {
  return (
    <div>AddFund</div>
  )
}

export default AddFund