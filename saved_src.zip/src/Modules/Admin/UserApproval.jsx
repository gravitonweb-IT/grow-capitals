import React from 'react'

const UserApproval = () => {
  return (
    <div>UserApproval</div>
  )
}

export default UserApproval