import React from 'react'

const Fund = () => {
  return (
    <div>Fund</div>
  )
}

export default Fund